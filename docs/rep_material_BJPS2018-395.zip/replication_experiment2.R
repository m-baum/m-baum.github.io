#######################################################################
##                                                                   ##
##  Title  : R Replication script for Experiment 2                   ##
##           of the BJPS manuscript BJPS-2018-395                    ##
##           "The PC Algorithm and the Inference to Constitution"    ##
##  Authors: Lorenzo Casini and Michael Baumgartner                  ##
##  Version: 02/04/2020                                              ##
##                                                                   ##
#######################################################################                                                                                                                  

# Required R packages
library(pcalg)
library(ggplot2)
library(reshape)
library(tikzDevice)
library(RCIT)

# Auxiliary Functions
sortString <- function(x){
  if(length(x)>0) {
  r <- strsplit(x, "\\|")
  r <- lapply(r, sort)
  lapply(r, paste0, collapse = "|")} else {
  x
  }
}

bidir <- function(x)  {
  if(length(x)>0){
  r <- expand.grid(x,x)
  r <- r[apply(r, 1, function(x) all(!duplicated(x))),]
  resul <- vector("logical",nrow(r))
  for(i in 1:nrow(r)){
    resul[i] <-  identical(sortString(as.character(r[i,1])),sortString(as.character(r[i,2])))
  }
  r <- cbind(r,resul)
  r <- as.matrix(r[which(r[,3]==TRUE),])
  unique(as.vector(r[,1:2]))
  } 
}

# RCTI wrapper function, thanks to Eric Strobl for sharing
RCIT_wrap <- function(x, y, z, suffStat){
  x1=suffStat$data[,x];
  y1=suffStat$data[,y];
  z1=suffStat$data[,z];
  out = RCIT:::RCIT(x1, y1, z1, num_f = 25);
  return(out$p)     
}

# Define test variants
variants <- c("series 1", "series 2")

# Define true graph
true.graph <- c("I|A", "I|B", "I|S", "A|B", "A|S", "Y|B", "A|G", "B|S", "B|G", "Z|A", "X|S")

# Number of trials
n <- 1000
# Sample Size
sampleSize <- 10000

# Draw seeds for replication
suppressWarnings(RNGversion("3.6.0")) # enforcing sampling method from R 3.6
set.seed(48) 
seeds.param <- sample(.Machine$integer.max, n)

# Initialize score lists
compare.variants <- score.list.storage <- data.storage <- analyses.storage <- vector("list", length(variants))

# Variant Loop
# ------------

for(m in 1:length(variants)){
  cat(m,  "variant","\n")

  variant <- variants[m]
  
  # Repetition Loop
  # -------------
  score.list.rep <- edges.list.rep <- data.list.rep <- analyses.rep <- vector("list", n)
  
  for(k in 1:n){
  cat(k, "\n")
  set.seed(seeds.param[k])
  
     # Sample error terms
     errorA <- rnorm(sampleSize,0)
     errorB <- rnorm(sampleSize,0)
     errorS <- rnorm(sampleSize,0)
     errorG <- rnorm(sampleSize,0)
     # errorC <- rnorm(sampleSize,0)

     # Sample exogenous variables
     p.range <- setdiff(-5:5,0) # parameter range
     I <- sample(p.range,1) + rnorm(sampleSize,0,sample(1:10,1)) 
     X <- sample(p.range,1) + rnorm(sampleSize,0,sample(1:10,1))
     Z <- sample(p.range,1) + rnorm(sampleSize,0,sample(1:10,1))
     Y <- sample(p.range,1) + rnorm(sampleSize,0,sample(1:10,1))
           
     # Sample endogenous parts A and B 
     A <- sample(p.range,1)*I + sample(p.range,1)*Z + errorA
     B <- sample(p.range,1)*I + sample(p.range,1)*A + sample(p.range,1)*Y + errorB

     # Sample G
     if(variant=="series 1"){G <- sample(p.range,1)*A + sample(p.range,1)*B 
     } else {G <- sample(p.range,1)*A + sample(p.range,1)*B  + errorG  
     }
     
     # Sample S
     S <- sample(p.range,1)*I + sample(p.range,1)*A + sample(p.range,1)*B + 
                                               sample(p.range,1)*X + errorS
     
     # Generate data list 
     data <- cbind(G,A,B,X,Z,Y,I,S)
     
     # Store data
     data.list.rep[[k]] <- data
      
     # Run PC
     V <- colnames(data) 
     suffStat = list(data = data)
     analysis <-  pc(suffStat, indepTest = RCIT_wrap, alpha = 0.05, labels = V, maj.rule = T)
     analyses.rep[[k]] <- analysis
     
     # Build all edges in graph
     edgesGraph <- arrowsGraph <-  gsub(".weight",'',
                                        attr(unlist(analysis@graph@edgeData@data),"names"))
     edgesGraph <- unlist(sortString(edgesGraph))  
     
     # Build all possible (un)directed edges 
     allEdges <- combn(colnames(data),2)
     allEdges <- apply(allEdges, 2, function(x) paste0(x[1],"|",x[2]))
     allEdges <- unlist(sortString(allEdges))
     
     allArrows <- expand.grid(colnames(data),colnames(data))
     allArrows <- allArrows[apply(allArrows, 1, function(x) all(!duplicated(x))),]
     allArrows <- as.vector(apply(as.matrix(allArrows), 1, function(x) paste0(x[1],"|",x[2])))

     # Score undirected edges recovered 
     score <- allEdges %in% edgesGraph
     score <- as.data.frame(matrix(score,nrow=1,ncol=length(allEdges),
            byrow = T,dimnames = list(1,allEdges)))    

     # False positives in undirected edges/AdjCompletness (true edges in Graph/edges in true graph)
     x <- unique(unlist(sortString(true.graph)))
     Adj.false.pos <- if(length(edgesGraph)>0){
                         length(setdiff(unique(unlist(sortString(edgesGraph))), x))/
                                                            length(unique(edgesGraph))
                        }else{0}
     AdjCompleteness <- length(intersect(unique(unlist(sortString(edgesGraph))),x))/length(x)
     score$Adj.false.pos <- Adj.false.pos
     score$AdjCompleteness <- AdjCompleteness

     # False positives in arrows/ArrCompleteness (Arr.true.pos/directed arrows in true graph)
     x <- true.graph
     z <- bidir(arrowsGraph) # bi- and undirectional edges in Graph
     dirArr <- setdiff(arrowsGraph,z) # directed edges in Graph
     Arr.false.pos <- if(length(dirArr)>0){
                         length(union(setdiff(dirArr,x),
                                      setdiff(unlist(sortString(z)), unlist(sortString(x)))))/
                                                                   length(unique(edgesGraph))
                         }else{0}
     ArrCompleteness <- length(intersect(dirArr,x))/length(x)

     score$Arr.false.pos <- Arr.false.pos
     score$ArrCompleteness <- ArrCompleteness
     score$pathAG <- "A|G" %in% dirArr 
     score$pathBG <- "B|G" %in% dirArr
     score$pathYS <- "Y|S" %in% dirArr
     score$pathYG <- "Y|G" %in% dirArr
     score$pathZG <- "Z|G" %in% dirArr
     score$pathIG <- "I|G" %in% dirArr
     score$pathGS <- "G|S" %in% dirArr
     score$pathGA <- "G|A" %in% dirArr
     score$pathGB <- "G|B" %in% dirArr
     score.list.rep[[k]] <-  score
    
     } # End repetition loop

   # Overall scoring
   overall.score <- do.call(rbind,score.list.rep)
   overall.ratio <-  matrix(1, ncol = ncol(overall.score), byrow = T,
           dimnames = list(1,names(overall.score)))
   
   
   for(i in 1:length(allEdges)){
       overall.ratio[1,i] <- length(which(overall.score[,i]))/nrow(overall.score)
   }
       overall.ratio[,c("Adj.false.pos")] <- mean(overall.score$Adj.false.pos)
       overall.ratio[,c("Arr.false.pos")] <- mean(overall.score$Arr.false.pos)
       overall.ratio[,c("AdjCompleteness")] <- mean(overall.score$AdjCompleteness)
       overall.ratio[,c("ArrCompleteness")] <- mean(overall.score$ArrCompleteness)
       overall.ratio[,c("pathAG")] <- length(which(overall.score[,c("pathAG")]))/nrow(overall.score)
       overall.ratio[,c("pathBG")] <- length(which(overall.score[,c("pathBG")]))/nrow(overall.score)
       overall.ratio[,c("pathYS")] <- length(which(overall.score[,c("pathYS")]))/nrow(overall.score)
       overall.ratio[,c("pathYG")] <- length(which(overall.score[,c("pathYG")]))/nrow(overall.score)
       overall.ratio[,c("pathZG")] <- length(which(overall.score[,c("pathZG")]))/nrow(overall.score)
       overall.ratio[,c("pathIG")] <- length(which(overall.score[,c("pathIG")]))/nrow(overall.score)
       overall.ratio[,c("pathGS")] <- length(which(overall.score[,c("pathGS")]))/nrow(overall.score)
       overall.ratio[,c("pathGA")] <- length(which(overall.score[,c("pathGA")]))/nrow(overall.score)
       overall.ratio[,c("pathGB")] <- length(which(overall.score[,c("pathGB")]))/nrow(overall.score)

    # Store analyses, data, scores
    analyses.storage[[m]] <- analyses.rep 
    data.storage[[m]] <-  data.list.rep
    score.list.storage[[m]] <- score.list.rep
    compare.variants[[m]] <- overall.ratio

}  # END variants loop

# Average number of edges per trial
# ---------------------------------
# Series 1
ana_sum_series1 <- lapply(score.list.storage[[1]], function(x) sum(as.matrix(x[1:28])))
mean(unlist(ana_sum_series1))

# Series 2
ana_sum_series2 <- lapply(score.list.storage[[2]], function(x) sum(as.matrix(x[1:28])))
mean(unlist(ana_sum_series2))

# Plot 2 (Figure 7)
# -------------------
selection <- lapply(compare.variants, function(x) x[,c("AdjCompleteness", "ArrCompleteness",
                                                        "Adj.false.pos", "Arr.false.pos", "pathAG",
                                                        "pathBG", "pathYG", "pathIG", "pathGS",
                                                        "pathGA", "pathGB", "pathYS")])
selection <- lapply(selection, setNames, c("edge.complete", "orient.complete", "edge.false.pos",
                                           "orient.false.pos",
                                            "A->G", "B->G", "Y->G", "I->G", "G->S", "G->A",
                                            "G->B", "Y->S"))
final.score <-  as.data.frame(do.call(rbind, selection))
final.score$variants <- factor(variants, levels = variants)
k1 <- melt(final.score, id.vars = "variants")
colnames(k1) <- c("variants", "property", "value")
plot2 <- ggplot(k1, aes(x = property, y = value,group = 1, fill = variants)) + 
  geom_bar(stat = "identity", position = position_dodge2(), width = .7) +
  scale_fill_grey(start = 0, end = .65)+
  theme_bw() + ylim(0, 1) + theme(legend.position="top") +
  theme(legend.title = element_blank()) +
  theme(plot.title = element_text(size = 9)) + 
  theme(axis.text.x = element_text(size = 8, angle = 45, hjust = 1)) +
  scale_x_discrete(name = "")

options(tz="CA")
tikz(file = "plot2.tex", width = 5.1, height = 3.4)
print(plot2)
dev.off()
getwd()

