###########################################################################
# Overview over replication material for                                  #
#                                                                         #
# Causal Modeling with Multi-Value and Fuzzy-Set Coincidence Analysis     #
# Michael Baumgartner & Mathias Ambuehl                                   #
#                                                                         #
# 11.06.2018                                                              #
#                                                                         #
###########################################################################


* The main file of the replication material is the R script "replication.R".

* The file "aux_functions.R" is a source file with auxiliary functions that must
  be placed in the working directory of the R session before running the "replication.R"
  (and subsequently loaded as a source file).
  
* Lines 10-94 of "replication.R" replicate the tables and analyses in sections
  2 and 3 of the paper.
  
* From line 98 onwards, the inverse search trials are replicated that are reported
  in section 4 of the paper an in the appendix.

* If the test series is run as a whole, tex files will be produced that contain the
  bar charts contained in the paper. For completeness, we add all the plots that 
  were generated when running the script on our local machine as well as a tex file
  that compiles these plots and combines them in a single pdf.
  
* We also add a txt file containing our sessionInfo() as well an image ("WorkSpace.RData")
  of our R workspace after running "replication.R" on our local machine. 