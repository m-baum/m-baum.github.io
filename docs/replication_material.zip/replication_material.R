
##################################################################################
##                                                                              ##
##  Title  : Configurational causal modeling and logic regression               ##
##           Replication script                                                 ##
##  Authors: Michael Baumgartner & Christoph Falk                               ##
##  Version: 03/31/2021                                                         ##
##                                                                              ##
##################################################################################

library(LogicReg)
library(cna)
library(cnaOpt)
library(plyr)
library(dplyr)
library(ggplot2)
library(reshape2)
library(stringr)
library(tikzDevice)
library(frscore)

source(".../aux_functions.R")



# Illustration example (Table 1)
# ##############################
# Generation of Table 1
# ---------------------
# Ideal data for ground truth "A*e + C*d <-> B"
datFull <- ct2df(full.ct("A*B*C*D*E"))
ground.truth <- "A*e + C*d <-> B"
ideal.dat <- ct2df(selectCases(ground.truth, datFull))
# cases incompatible with ground truth
incomp.dat <- dplyr::setdiff(datFull,ideal.dat)
# introduce 10% of rows incompatible with 
nratio <- 0.1
set.seed(1368157140)
x <- bring_theNoise(ideal.dat, incomp.dat, no.replace = round(nrow(ideal.dat )*nratio), add = T)
# introduce multiple instances of some configurations
x <- some(x,50,replace=T) 
# introduce fragmentation
x <- some(configTable(x),16, replace = F) 
tab1 <- x[,c(1,3,4,5,2)]  # this is Table 1 in the paper

# Coincidence Analysis (CNA)
# --------------------------
# Analyze tab1 with CNA at con = cov = 0.8
cna(tab1, ordering = list("B"),strict=T, con=.8, cov=.8)
# increase consistency threshold to con = 0.95, cov = 0.75
cna(tab1, ordering = list("B"),strict=T, con=.8, cov=.95)
# decrease consistency threshold to con = 0.7, cov = 0.7
cna(tab1, ordering = list("B"),strict=T, con=.7, cov=.7)
# Robustness scoring in the interval [0.65,0.95]
fs_select <- frscored_cna(tab1, fit.range = c(0.95, 0.65), 
                         granularity = 0.1, output = "asf", ordering = list("B"),strict=T, what="a")
fs_select

# Logic Regression (LR)
# --------------------
# Re-analyze tab1 100 times with LOG REG without overfitting provisions,
# 25000 iterations, 9 leaves maximum
n <- 100
df.tab1 <- ct2df(tab1)
repeats.without <- vector("list", n) 
set.seed(7)
for(i in 1:n){
cat(i, "\n")
    myanneal <- logreg.anneal.control(start = -1, end = -4, iter = 25000, update = -1)
    l <- logreg(df.tab1$B, df.tab1[,-5], select=1,ntrees = 1, nleaves=9, type = 2,
              anneal.control = myanneal)
    ex <- translateT(capture.output(l)[length(capture.output(l))]) 
    if(stringr:::str_detect(ex, "[A-J,a-j]")&&!nchar(gsub(" ","",ex))==2) 
    {
    logMod <- paste0(ereduce(cna:::getCond(selectCases(ex))), "<->B")
    } else if(stringr:::str_detect(ex, "[-]")&&nchar(gsub(" ","",ex))==2) {
    ex <- gsub("-","",ex)
    ex <- stringr:::str_to_lower(ex)
    logMod <- paste0(ereduce(cna:::getCond(selectCases(ex))), "<->B")
    } else {logMod <- NA}
  repeats.without[[i]] <- logMod
}
table(unlist(repeats.without))
# Re-analyze tab1 100 times with LR with overfitting provisions,
# 25000 iterations, 9 leaves maximum, penalty = 2, null model permutation test (select = 4)
n <- 100
repeats.with <- vector("list", n) 
set.seed(11)
for(i in 1:n){
cat(i, "\n")
    myanneal <- logreg.anneal.control(start = -1, end = -4, iter = 25000, update = -1) 
    l <- logreg(df.tab1$B, df.tab1[,-5], select=1,ntrees = 1, nleaves=9, type = 2,
              anneal.control = myanneal, penalty = 2) # lowering the penalty to 1 does not reliably remove overfitting
    l2 <- logreg(select = 4, oldfit = l, mc.control= logreg.mc.control(nburn=500, niter=10000, hyperpars=log(2), output=-2))
    if(l2$nullscore>=l2$bestscore){
    ex <- translateT(capture.output(l)[length(capture.output(l))]) 
    if(stringr:::str_detect(ex, "[A-J,a-j]")&&!nchar(gsub(" ","",ex))==2) 
    {
    logMod <- paste0(ereduce(cna:::getCond(selectCases(ex))), "<->B")
    } else if(stringr:::str_detect(ex, "[-]")&&nchar(gsub(" ","",ex))==2) {
    ex <- gsub("-","",ex)
    ex <- stringr:::str_to_lower(ex)
    logMod <- paste0(ereduce(cna:::getCond(selectCases(ex))), "<->B")
    } else {logMod <- NA}
    } else {logMod <- NA}
  repeats.with[[i]] <- logMod
}
table(unlist(repeats.with))



# Benchmark experiment section 5
# ##############################

n <- 1000 #number of datasets


#sample size by factor
samplesize <- c(60,200,1000)

outcome <- "D"

noise <- c(0.05,0.15,0.25,0.35)
setlist <- list(samplesize, noise)

settings <- expand.grid(setlist) #combinations of sample size, noise ratio
colnames(settings) <- c("ssize", "noise") 

storage <- vector("list", nrow(settings))

# prepare score sheet
results <- matrix( nrow = nrow(settings),ncol=12, dimnames = list(1:nrow(settings), 
                                   c("ssize", "noise","LR.ffree", "LR.correct", "LR.complete","LR.ambig", "LR.speed",
                                     "CNA.ffree", "CNA.correct", "CNA.complete","CNA.ambig", "CNA.speed") ))

results[,1] <- settings[,1]
results[,2] <- settings[,2]
set.seed(3) #seed for selecting seeds
seeds <- sample(.Machine$integer.max, nrow(settings))

# create the ground truth DGSs that are the search targets
datFull <- ct2df(full.ct(8))
target <- replicate(n, randomAsf(datFull, outcome = outcome, compl = 2:3))
ideal.data <- lapply(lapply(target, function(x) selectCases(x, datFull)), ct2df) 
incomp.data <- lapply(lapply(ideal.data, function(x) dplyr::setdiff(datFull,x)), ct2df) 

for(s in 1:nrow(settings)){
      cat(s, "setting \n")
   set.seed(seeds[s])

   scoreLogReg <- scoreLogRegComp <- speedLR <- interm_speedLR <- speedCNA <- interm_speedCNA <- scoreCNA <-  scoreCNAComp <-  vector("list", n) 

   # Generate Data
   #--------------
   # introduce some randomized degree of fragmentation between 0% and 50% into medium and large size data 
   frag.data <- lapply(ideal.data,function(x) if(settings[s,1]!=60){x[sample(1:nrow(x),
                                                      sample((nrow(x)*0.5):nrow(x),1),replace=F),]}else{x})
   # set sample size, which may or may not introduce additional fragmentation
   testdata <-  lapply(frag.data,function(x) x[sample(1:nrow(x),settings[s,1],replace=T),]) 
    # range(mapply(function(x,y) (nrow(y)-nrow(setdiff(y,x)))/nrow(y),x=testdata,y=ideal.data))
   
   # set noise ratio
   nratio <- settings[s,2]
   # introduce noise
    Noisedata <- vector("list", length(testdata))
   for (i in 1:length(testdata)){
     no.replace <- round(nrow(testdata[[i]])*nratio)
     a <- testdata[[i]][sample(nrow(testdata[[i]]), nrow(testdata[[i]])-no.replace , replace = FALSE),]
     b <- some(incomp.data[[i]], no.replace)
     Noisedata[[i]] <- rbind(a, b)
   }
    # Logic Regression
    #-----------------
    # ANALYSIS
     for (i in 1:length(Noisedata)){
       cat(i, "LR \n")
      ## ANNEAL
      myanneal <- logreg.anneal.control(start = -1, end = -4, iter =25000, update = -1)
      # ### with null hypothesis PERMUTATION test + complexity penalty of 2 (=AIC)
      start_time <- Sys.time()
       l <- logreg(Noisedata[[i]]$D, Noisedata[[i]][,-4], select=1, ntrees = 1, nleaves = 9, type = 2,
           anneal.control = myanneal, penalty = 2)
       interm_time <- Sys.time()
       l2 <- logreg(select = 4, oldfit = l, mc.control=
                    logreg.mc.control(nburn=500, niter=25000, hyperpars=log(2), output=-2))
       end_time <- Sys.time()
       interm_speedLR[[i]] <- as.vector(interm_time -  start_time)
       if(l2$nullscore>=l2$bestscore){
       ex <- translateT(capture.output(l)[length(capture.output(l))])
       if(stringr:::str_detect(ex, "[A-J,a-j]")&&!nchar(gsub(" ","",ex))==2)
        {
        logMod <- paste0(ereduce(cna:::getCond(selectCases(ex))), "<->D")
        } else if(stringr:::str_detect(ex, "[-]")&&nchar(gsub(" ","",ex))==2) {
        ex <- gsub("-","",ex)
        ex <- stringr:::str_to_lower(ex)
        logMod <- paste0(ereduce(cna:::getCond(selectCases(ex))), "<->D")
        } else {logMod <- NULL}
      } else {logMod <- NULL}
      speedLR[[i]] <-  as.vector(end_time - start_time)
      corrLR <- is.submodel(logMod,target[[i]])
      scoreLogReg[[i]] <- corrLR
      if(!length(corrLR)==0 && any(corrLR)) {scoreLogRegComp[[i]] <- max(getcomp(logMod))/getcomp(target[[i]])
      } else if(!length(corrLR)==0 && !any(corrLR)){ scoreLogRegComp[[i]] <- 0
      } else if(length(corrLR)==0){scoreLogRegComp[[i]] <- 0}
    }
    #
    #
    # SCORING
    # error-freeness
    ff.LR <- unlist(lapply(scoreLogReg,function(x) any(x)||length(x)==0))
    results[s,3] <- length(which(ff.LR))/n
     # correctness
    cor.LR <- unlist(lapply(scoreLogReg, any))
    results[s,4] <- length(which(cor.LR))/n
    # completeness
    results[s,5] <- mean(unlist(scoreLogRegComp),na.rm=T)
    # ambiguity
    results[s,6] <- mean(unlist(lapply(scoreLogReg, length)))
    # speed
    results[s,7] <- mean(unlist(speedLR))


    # CNA
    # ---
    # ANALYSIS
    # 
    for (i in 1:length(Noisedata)){
      cat(i, "CNA \n")
      # with ROBUSTNESS analysis
      start_time <- Sys.time()
      clres <- rean_cna(Noisedata[[i]], ordering = list(outcome), strict = TRUE,  
                       what = "a",attempt = seq(1,0.6, -0.1), maxstep=c(3,3,9), 
                       output = "asf")
      interm_time <- Sys.time()
      rescomb <- rbind.fill(clres)
      FRscore_selected <- if (nrow(rescomb)!=0){
         cna_fr <- frscore(rescomb$condition, maxsols = 70)
         cna_fr <- cna_fr$models[cna_fr$models$score >= quantile(cna_fr$models$score, 0.95, na.rm = T),]
         cna_fr
        }
       end_time <- Sys.time()
       interm_speedCNA[[i]] <- as.vector(interm_time - start_time)
       speedCNA[[i]] <- as.vector(end_time - start_time)
       cnaMod <- FRscore_selected$model
       if(!(is.na(cnaMod)||length(cnaMod)==0)) {
       corrCNA <- is.submodel(cnaMod, target[[i]])
       } else{corrCNA <- NA}
    
      scoreCNA[[i]] <- corrCNA
        if(!is.na(corrCNA)&&any(corrCNA)) {scoreCNAComp[[i]] <- max(getcomp(cnaMod[which(corrCNA)]))/getcomp(target[[i]])
        } else if(!is.na(corrCNA)&&!any(corrCNA)){ scoreCNAComp[[i]] <- 0
        } else if(is.na(corrCNA)){scoreCNAComp[[i]] <- 0}
      }

    # error-freeness
    ff.cna <- unlist(lapply(scoreCNA,function(x) any(x)||is.na(x)))
    results[s,8] <- length(which(ff.cna))/n
    # correctness
    cor.cna <- unlist(lapply(scoreCNA, function(x) any(x, na.rm = T)))
    results[s,9] <- length(which(cor.cna ))/n
    # completeness
    results[s,10] <- mean(unlist(scoreCNAComp), na.rm = T)
    # ambiguity
    ambi <- scoreCNA
    ambi <- lapply(ambi, function(x)if(is.na(x)){x <- 0}else{x <- length(x)})
    results[s,11] <- mean(unlist(ambi))
    # speed
    results[s,12] <- mean(unlist(speedCNA))

storage[[s]] <- list(scoreLogReg, scoreLogRegComp, speedLR, speedCNA, scoreCNA ,
                     scoreCNAComp, interm_speedLR, interm_speedCNA)

}

# Results
# #######


# Model complexity
# ----------------
# mean model complexity when at least one model is issued
score.complexLR <-score.complexCNA <- vector("list", length(storage))
for(i in 1:length(storage)){
  cat(i, "\n")
  modelsLR_nonNull <- vector("list", length(storage[[i]][[1]]))
  for(j in 1:length(storage[[i]][[1]])){
  modelsLR_nonNull <- storage[[i]][[1]][!sapply(storage[[i]][[1]], identical, logical(0))]
  }
  score.complexLR[[i]] <- lapply(modelsLR_nonNull,function(x) mean(getcomp(names(x))))
  
  modelsCNA_nonNull <- vector("list", length(storage[[i]][[5]]))
  for(j in 1:length(storage[[i]][[5]])){
  modelsCNA_nonNull <- storage[[i]][[5]][!sapply(storage[[i]][[5]], identical, NA)]
  }
  score.complexCNA[[i]]  <- lapply(modelsCNA_nonNull,function(x) mean(getcomp(names(x))))
  
}
# Mean complexity of LR 
mean(unlist(lapply(score.complexLR, function(x) mean(unlist(x)))))

# Mean complexity of CNA 
mean(unlist(lapply(score.complexCNA, function(x) mean(unlist(x)))))


# Speed
# -----

# average overall execution times
# LR
LRtimes <- lapply(storage, function(x) mean(unlist(x[[3]])))
mean(unlist(LRtimes))

# times without permutation test and post-processing
LRtimes_interm <- lapply(storage, function(x) mean(unlist(x[[7]])))
mean(unlist(LRtimes_interm))

# CNA
CNAtimes <- lapply(storage, function(x) mean(unlist(x[[4]])))
mean(unlist(CNAtimes))

# times without robustness check
CNAtimes_interm <- lapply(storage, function(x) mean(unlist(x[[8]])))
mean(unlist(CNAtimes_interm))


# Number of models
# ----------------
# mean LR ambiguous
mean(results[,6])
# mean CNA ambiguous
mean(results[,11])


# Synergy potential 
# #################

results
storage
# 
# storage <- readRDS("/Users/baumgartner/Dropbox/CNA_Project/LogReg/paper/results/storage_final.RDS")
# results <- readRDS("/Users/baumgartner/Dropbox/CNA_Project/LogReg/paper/results/results_final.RDS")

# Identical models
# ----------------
# At least one identical model returned 
score.ident <- vector("list", length(storage))
for(i in 1:length(storage)){
  cat(i, "\n")
  modelsLR <- lapply(storage[[i]][[1]],names)
  modelsCNA <- lapply(storage[[i]][[5]],names)
  score.ident[[i]] <- mapply(function(x,y)contains.id.models(x,y), x=modelsLR,y=modelsCNA )
}
ra <- lapply(score.ident, function(x) lapply(x, function(y) any(y)))
identModels <- unlist(lapply(ra, function(x) length(x[x == TRUE])/n))
results <- cbind(results,identModels)
mean(identModels)

# error-freeness among identical models
sub <- lapply(score.ident, function(x) lapply(x, function(y) y[y == TRUE]))
ident.ff <- vector("list", length(sub))
for(i in 1:length(sub)){
  cat(i, "\n")
  ident.ff.sub <- vector("list", length(sub[[i]]))
  for(j in 1:length(sub[[i]])){
    
   ident.ff.sub[[j]] <- if(length(sub[[i]][[j]])>0 && !names(sub[[i]][[j]]) %in% "empty"){
                         is.submodel(names(sub[[i]][[j]]),target[[j]])
                          } else if(length(sub[[i]][[j]])>0 && names(sub[[i]][[j]]) %in% "empty") {TRUE
                         } else {sub[[i]][[j]]}
  }
 ident.ff[[i]] <- ident.ff.sub
  
}
ident.ff <- lapply(ident.ff, function(x)  x[!sapply(x, identical, logical(0))])
identModels.ff <- unlist(lapply(ident.ff, function(x) length(which(unlist(x)==TRUE))/length(unlist(x))))
results <- cbind(results,identModels.ff)
# mean LR error-free
mean(results[,3])
# mean CNA error-free
mean(results[,8])
# mean error-free when CNA=LR
mean(results[,14])

# Correctness among identical models
ident.corr <- vector("list", length(sub))
for(i in 1:length(sub)){
  cat(i, "\n")
  ident.corr.sub <- vector("list", length(sub[[i]]))
  for(j in 1:length(sub[[i]])){
    
   ident.corr.sub[[j]] <- if(length(sub[[i]][[j]])>0 && !names(sub[[i]][[j]]) %in% "empty"){
                         is.submodel(names(sub[[i]][[j]]),target[[j]])
                          } else if(length(sub[[i]][[j]])>0 && names(sub[[i]][[j]]) %in% "empty") {FALSE
                         } else {sub[[i]][[j]]}
  }
 ident.corr[[i]] <- ident.corr.sub
  
}
ident.corr <- lapply(ident.corr, function(x)  x[!sapply(x, identical, logical(0))])
identModels.corr <- unlist(lapply(ident.corr, function(x) length(which(unlist(x)==TRUE))/length(unlist(x))))
results <- cbind(results,identModels.corr)

# mean LR correct
mean(results[,4])
# mean CNA correct
mean(results[,9])
mean(results[which(results$noise==0.35),9])
# mean correct when LR = CNA
mean(results[,15])
# mean correct when LR = CNA and the methods typically output non-empty models
mean(results[-c(7,10,11),15])

# Completeness among identical models
ident.comp <- lapply(ident.corr, function(x) lapply(x, function(y) if(any(y)) {max(getcomp(names(y[which(y)])))/getcomp(attr(y,"target"))
                                  } else {0}))
identModels.comp <- unlist(lapply(ident.comp, function(x) mean(unlist(x))))
results <- cbind(results,identModels.comp)
# mean LR complete
mean(results[,5])
# mean LR complete in small sized data
mean(results[which(results$ssize==60),]$"LR.complete")
mean(results[which(results$ssize==1000),]$"LR.complete")
# mean CNA complete
mean(results[,10])
mean(results[which(results$ssize==60),]$"CNA.complete")
mean(results[which(results$ssize==1000),]$"CNA.complete")
# mean complete when CNA=LR
mean(results[,16])
mean(results[which(results$ssize==1000),16])

# Submodels
# ---------
# at least one submodel(CNA, LR) OR submodel(LR,CNA)
score.sub <- vector("list", length(storage))
for(i in 1:length(storage)){
  cat(i, "\n")
  modelsLR <- lapply(storage[[i]][[1]],names)
  modelsCNA <- lapply(storage[[i]][[5]],names)
  score.sub[[i]] <- mapply(function(x,y)contains.sub.models(x,y), x=modelsLR,y=modelsCNA )
}
subModels <- lapply(score.sub, function(x) lapply(x, any))
subModels <- unlist(lapply(subModels, function(x) length(x[x == TRUE])/n))
results <- cbind(results,subModels)
# Frequency of trials in which CNA and LR produce submodels
mean(results[,17])
# mean subModels in scenarios where LR outputs non-empty models more often than not
mean(results[-c(7,10,11),17])


# error-freeness of submodels when submodel(CNA, LR) OR submodel(LR,CNA)
true.submodels <- lapply(score.sub,function(x)lapply(x, function(y) y[which(y)]))
true.submodel.pairs <- lapply(true.submodels, function(x) lapply(x, function (y) str_split(names(y),",",simplify = F)))

true.submodel.pairs.min <- lapply(true.submodel.pairs,function(x) lapply(x, function(y) 
              lapply(y,function(z)  z[which.min(getcomp(z))])))
true.submodel.pairs.min <-  lapply(true.submodel.pairs.min, function(x) lapply(x, function(y) unlist(y)))
true.submodel.pairs.min <-  lapply(true.submodel.pairs.min, function(x) lapply(x, unique))
true.submodel.pairs.min.ff <- lapply(true.submodel.pairs.min,function(x) mapply(function(y,t) 
                                     if(length(y)>0 && y!="empty") {is.submodel(y,t)} else if(length(y)>0 && y=="empty"){
                                                                            TRUE}, y=x,t=target ))
ff.ratio.min <- lapply(true.submodel.pairs.min.ff, function(x)  x[!sapply(x, is.null)])
ff.ratio.min <- lapply(ff.ratio.min, function(x) lapply(x, any))
ff.ratio.min <- lapply(ff.ratio.min,function(x) unlist(x))
subModels.ff <- lapply(ff.ratio.min,function(x) length(x[x==TRUE])/length(x))
subModels.ff <- unlist(subModels.ff)
results <- cbind(results,subModels.ff)
# mean error-freeness among submodels when submodel(CNA, LR) OR submodel(LR,CNA)
mean(results[,18])

# Correctness of submodels when submodel(CNA, LR) OR submodel(LR,CNA)
true.submodel.pairs.min <- lapply(true.submodel.pairs,function(x) lapply(x, function(y) 
              lapply(y,function(z)  z[which.min(getcomp(z))])))
true.submodel.pairs.min <-  lapply(true.submodel.pairs.min, function(x) lapply(x, function(y) unlist(y)))
true.submodel.pairs.min <-  lapply(true.submodel.pairs.min, function(x) lapply(x, unique))
true.submodel.pairs.min.correct <- lapply(true.submodel.pairs.min,function(x) mapply(function(y,t) 
                                     if(length(y)>0 && y!="empty") {is.submodel(y,t)} else if(length(y)>0 && y=="empty"){
                                                                            FALSE}, y=x,t=target ))
correct.ratio.min <- lapply(true.submodel.pairs.min.correct, function(x)  x[!sapply(x, is.null)])
correct.ratio.min <- lapply(correct.ratio.min, function(x) lapply(x, any))
correct.ratio.min <- lapply(correct.ratio.min,function(x) unlist(x))
subModels.corr <- lapply(correct.ratio.min,function(x) length(x[x==TRUE])/length(x))
subModels.corr <- unlist(subModels.corr)
results <- cbind(results,subModels.corr)
# mean correctness among submodels when submodel(CNA, LR) OR submodel(LR,CNA)
mean(results[,19])


# Completeness among submodels when submodel(CNA, LR) OR submodel(LR,CNA)
comp.ratio.min <- lapply(true.submodel.pairs.min.correct,function(x) lapply(x,function(y)  if(any(y)){y[which(y)]}else{y}  ))
comp.ratio.min <- lapply(comp.ratio.min,function(x) lapply(x,function(y)  if(length(y)>0 && y){y[which.max(getcomp(names(y)))]}else{y}  ))
comp.ratio.min  <- lapply(comp.ratio.min, function(x)  mapply(function(y,t) if(length(y)>0 && y){ max(getcomp(names(y)))/getcomp(t)}else if(
                                                                    length(y)>0 && !y) {0} else {y} ,y=x,t=target ))
comp.ratio.min <- lapply(comp.ratio.min , function(x)  x[!sapply(x, is.null)])
comp.ratio.min <-  lapply(comp.ratio.min, unlist)
subModels.comp <- unlist(lapply(comp.ratio.min, mean))
results <- cbind(results,subModels.comp)
# mean completeness among min complex submodels when submodel(CNA, LR) OR submodel(LR,CNA)
mean(results[,20])




#####################
# PLOTS
# #####
# Figure 1
# ********
selection1 <- as.data.frame(results[,c(1:5,8:10)])
selection1 <- selection1 %>% group_by(noise, ssize, LR.ffree,CNA.ffree,LR.correct,CNA.correct,LR.complete,
                                      CNA.complete) 
k1 <- melt(selection1, id.vars = c("noise",  "ssize")) 
k1$lab <- c(rep("LR", 36), rep("CNA", 36))
colnames(k1) <- c("noise", "ssize","variable", "value", "lab","se")
k1$variable<- rep(c(rep("error-freeness",12),rep("correctness", 12), rep("completeness", 12)),2)
k1$variable <- factor(k1$variable,levels = c("error-freeness","correctness","completeness"))
k1$noise <- k1$noise*100
k1$noise<- as.character(k1$noise)
k1$noise <- paste0(k1$noise,"%")
k1$noise <- factor(k1$noise,levels = c("5%","15%","25%","35%"))
k1 <- k1 %>% tidyr:::unite("BothLabels", variable, ssize, sep = ", n=", remove = FALSE)
k1$BothLabels <- factor(k1$BothLabels,levels = unique(k1$BothLabels))

plot1 <- ggplot(k1, aes(x = noise, y = value,fill = lab)) +
  geom_bar(stat="identity", position = position_dodge(width = .5), width=.4) +
  scale_fill_manual(values=c('#303030','#C0C0C0')) +
  theme_bw() +facet_wrap(vars(BothLabels)) +
 theme(plot.title = element_text(size = 3), axis.text.x = element_text( size = 8 ), 
        axis.text.y = element_text( size = 8 ),axis.title = element_text( size = 8), legend.spacing.x = unit(0.5, 'cm'),
        legend.title = element_blank(),strip.text = element_text(size = 8),
       legend.text=element_text(size=8,margin = margin(l = -8, r=10,unit = "pt")))+
   scale_x_discrete(name ="noise ratio")+ylim(0, 1) +theme(legend.position="top") +
   ylab("benchmark score") 


plot1

# Figure 2
# --------

selection3 <- as.data.frame(results[,c(1,2,13:16)])
selection3 <- selection3 %>% group_by(noise, ssize) 
k1 <- melt(selection3, id.vars = c("noise",  "ssize")) 
k1$variable<- c(rep("CNA=LR",12),rep("error-freeness",12), rep("correctness", 12),rep("completeness", 12))
k1$variable <- factor(k1$variable,levels = c("CNA=LR","error-freeness", "correctness","completeness"))
k1$noise <- k1$noise*100
k1$noise<- as.character(k1$noise)
k1$noise <- paste0(k1$noise,"%")
k1$noise <- factor(k1$noise,levels = c("5%","15%","25%","35%"))
k1$ssize <- paste0("n=",k1$ssize)
k1$ssize <- factor(k1$ssize,levels = c("n=60","n=200","n=1000"))
# k1 <- k1 %>% unite("BothLabels", variable, ssize, sep = ", n=", remove = FALSE)
# k1$BothLabels <- factor(k1$BothLabels,levels = unique(k1$BothLabels))

plot2 <- ggplot(k1, aes(x = noise, y = value,fill = variable)) +
  geom_bar(stat="identity", position = position_dodge(width = .7), width=.6) +
  scale_fill_grey(start = 0, end = 0.9) +
  theme_bw() + facet_wrap(vars(ssize),scales = "free_x") +
  theme(plot.title = element_text(size = 3), axis.text.x = element_text( size = 8 ), 
        axis.text.y = element_text( size = 8 ),axis.title = element_text( size = 8), legend.spacing.x = unit(0.5, 'cm'),
        legend.title = element_blank(),strip.text = element_text(size = 8),legend.text=element_text(size=8,margin = margin(l = -8, r=14,unit = "pt")))+
   scale_x_discrete(name ="noise ratio") +theme(legend.position="top") +
   ylab("mean score") 

plot2


# Figure 3
# --------

selection4 <- as.data.frame(results[,c(1,2,17:20)])
selection4 <- selection4 %>% group_by(noise, ssize) 
k1 <- melt(selection4, id.vars = c("noise",  "ssize")) 
k1$variable<- c(rep("sub(CNA,LR)",12),rep("error-freeness",12), rep("correctness", 12),rep("completeness", 12))
k1$variable <- factor(k1$variable,levels = c("sub(CNA,LR)","error-freeness","correctness","completeness"))
k1$noise <- k1$noise*100
k1$noise<- as.character(k1$noise)
k1$noise <- paste0(k1$noise,"%")
k1$noise <- factor(k1$noise,levels = c("5%","15%","25%","35%"))
k1$ssize <- paste0("n=",k1$ssize)
k1$ssize <- factor(k1$ssize,levels = c("n=60","n=200","n=1000"))

plot3 <- ggplot(k1, aes(x = noise, y = value,fill = variable)) +
  geom_bar(stat="identity", position = position_dodge(width = .7), width=.6) +
  # geom_text(aes(x = noise, vjust = -3),
            # position = position_dodge(0.7), size = 1.7, show.legend = F) +
  scale_fill_grey(start = 0, end = 0.9) +
   theme_bw() + facet_wrap(vars(ssize),scales = "free_x") +
  theme(plot.title = element_text(size = 3), axis.text.x = element_text( size = 8 ), 
        axis.text.y = element_text( size = 8 ),axis.title = element_text( size = 8), legend.spacing.x = unit(0.5, 'cm'),
        legend.title = element_blank(),strip.text = element_text(size = 8),legend.text=element_text(size=8,margin = margin(l = -8, r=14,unit = "pt")))+
   scale_x_discrete(name ="noise ratio") +theme(legend.position="top") +
   ylab("mean score") 

plot3

# Figure 4
# --------
compLR <- vector("list", 12)
compCNA <- vector("list",12)
for(i in 1:12){
compLR[[i]] <- unlist(storage[[i]][[2]])
compCNA[[i]] <- unlist(storage[[i]][[6]])
}

comp.score <- settings[rep(seq_len(nrow(settings)), each = 1000), ]
comp.score <- rbind(comp.score,comp.score)
x <- Reduce(c,compLR)
y <- Reduce(c,compCNA)
comp.score$value <- c(x,y)
comp.score$lab <- c(rep("LR", 12000), rep("CNA", 12000))

comp.score$noise <- comp.score$noise*100
comp.score$noise<- as.character(comp.score$noise)
comp.score$noise <- paste0(comp.score$noise,"%")
comp.score$noise <- factor(comp.score$noise,levels = c("5%","15%","25%","35%"))
comp.score <- comp.score %>% tidyr:::unite("BothLabels", noise, ssize, sep = ", n=", remove = FALSE)
comp.score$BothLabels <- factor(comp.score$BothLabels,levels = unique(comp.score$BothLabels))

plot4 <- ggplot(comp.score, aes(x = value,fill = lab)) +
   geom_histogram(bins=20,position="dodge")+ylim(0, 400) +xlim(0, 1)+facet_wrap(vars(BothLabels),ncol = 3) +theme(legend.position="top")+
   theme(plot.title = element_text(size = 3), axis.text.x = element_text( size = 8 ), 
        axis.text.y = element_text( size = 8 ),axis.title = element_text( size = 8), legend.spacing.x = unit(0.5, 'cm'),
        legend.title = element_blank(),strip.text = element_text(size = 8),
        legend.text=element_text(size=8,margin = margin(l = -8, r=10,unit = "pt")))
plot4 

