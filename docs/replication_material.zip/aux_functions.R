
##################################################################################
##                                                                              ##
##  Title  : Configurational causal modeling and logic regression               ##
##           Auxiliary functions (to be sourced in the replication script)      ##
##  Authors: anonymized                                                         ##
##  Version: 26/06/2020                                                         ##
##                                                                              ##
##################################################################################


# translates logic trees output by LR into Boolean notation
translateT <- function(x){
   s <- x
   if(stringr:::str_detect(s, "[-]")) { 
     s <- stringr:::str_remove_all(s,"[0-9,.,*]")
     }
   if(stringr:::str_detect(s, "[+]"))  {
     s <- stringr:::str_remove_all(s,"[0-9,.,+,*]")
     }
   s <- stringr:::str_replace_all(s,c("and"), c("*"))
   s <- stringr:::str_replace_all(s,c("or"), c("+"))
   s <- stringr:::str_replace_all(s,c("not"), c("-"))
   s <- gsub(" ", "", s, fixed = TRUE)
   s <- gsub("()+", "", s, fixed = TRUE)
   s <- gsub("()*", "A*a*", s, fixed = TRUE)
   s <- gsub("-e-","",s, fixed = TRUE)
   s <- gsub("e-","",s, fixed = TRUE)
   s
}

# checks whether the score lists of LR and CNA contain identical models
contains.id.models <- function(x,y){
  if((is.null(x)&&!is.null(y)) || (is.null(y)&&!is.null(x)) ){
  out <- FALSE
  } else if((is.null(x)&&is.null(y))){
  out <- TRUE
  names(out) <- "empty"
  # if((is.null(x)||is.null(y))){
  # out <- FALSE
  } else {
  t <- expand.grid(x,y,stringsAsFactors = FALSE)
  score <- vector("list", nrow(t))
  for(i in 1:nrow(t)){
    score[[i]] <- identical.model(t[i,1], t[i,2])
    if(score[[i]]==TRUE){
      names(score[[i]]) <-t[i,2]} 
  }
  # if(any(unlist(score))){out <- TRUE} else {out <- FALSE}
  out <- unlist(score)
  }
  return(out)
}

# checks whether the score lists of LR and CNA contain models related by the submodel relation
contains.sub.models <- function(x,y){
  if((is.null(x)&&!is.null(y)) || (is.null(y)&&!is.null(x)) ){
  out <- FALSE
  } else if((is.null(x)&&is.null(y))){
  out <- TRUE
  names(out) <- "empty"
  # if((is.null(x)||is.null(y))){
  # out <- FALSE
  } else {
  t <- expand.grid(x,y,stringsAsFactors = FALSE)
  score <- vector("list", nrow(t))
  for(i in 1:nrow(t)){
    score[[i]] <- as.vector(is.submodel(t[i,1],t[i,2])||is.submodel(t[i,2],t[i,1]))
    if(score[[i]]==TRUE){
      names(score[[i]]) <-paste0(t[i,1],",",t[i,2])} 
  }
  # if(any(unlist(score))){out <- TRUE} else {out <- FALSE}
  out <- unlist(score)
  }
  return(out)
}

# Introduce random noise to a data set. 
bring_theNoise <- function(cleandata, incomp.data, no.replace, add=FALSE, bias=NULL){
  if (add){
    
    a <- cleandata
    b <- some(incomp.data, no.replace, replace = TRUE, prob=bias)
    Noisedata <- rbind(a, b)
    
  } else {
    
    a <- cleandata[sample(nrow(cleandata), nrow(cleandata)-no.replace, replace = FALSE),]
    b <- some(incomp.data, no.replace, replace = TRUE, prob=bias)
    Noisedata <- rbind(a, b)
  }
  return(Noisedata)
}

seLog <- function(x){
    countTrue <- length(which(x))
    countFalse <- length(which(x==FALSE))
    mean <- length(which(x))/n
    StandardVar <- (1/(n-1))*((countTrue*((1-mean)^2))+(countFalse*((0-mean)^2)))
    StandardDev <- sqrt(StandardVar)
    StandardErr <- StandardDev/sqrt(n)
    StandardErr
    }

se <- function(x) sqrt(var(x)/length(x))


getcomp <-cna:::getComplexity

